<div id="menuSuperior" >
    <div class="void"></div>
    <ul id="ListaMenuSuperior" >
        <li><a href="/clubes-pro">CLUBES PRO</a></li>
        <li><a href="/PVSP">1 VS 1</a></li>
        <li><a href="/Reglamento">REGLAMENTO</a></li>
        <li><a href="/Clips">CLIPS</a></li>
        <li><a href="/Noticias">NOTICIAS</a></li>
        <?php if(Auth::check()): ?>
            <li id="LoginMenu">
                <a href="#" >
                    <div id="LogoEquipo" style="
                            background:url(https://avatar-ssl.xboxlive.com/avatar/<?php echo e(Auth::User()->gamertag); ?>/avatarpic-l.png);
                            background-size:cover;"></div>
                    <?php echo e(Auth::User()->user_name); ?>

                </a>
                <ul class="sub-menu">
                    <li style="font-size: 12px; "><a href="/Perfil" >Ver Perfil</a></li>
                    <li style="font-size: 12px; "><a href="/EditarPerfil" >Editar Perfil</a></li>
                    <li style="font-size: 12px; "><a href="/auth/logout" >Cerrar sesión</a></li>
                </ul>
            </li>

            <li id="notifications">
                <a href="#" >
                    Notificaciones (<?php echo e(Auth::user()->notifications->count()); ?>)
                </a>
                <ul class="sub-menu">
                    <?php foreach(Auth::user()->notifications as $notification): ?>
                        <li>
                            <a href="<?php echo e($notification->getLink()); ?>" ><?php echo e($notification->getMessage()); ?></a>
                            <a class="btn btn-danger" href="<?php echo e($notification->getDeleteLink()); ?>">X</a>
                        </li>
                    <?php endforeach; ?>

                </ul>
            </li>
        <?php else: ?>
            <li id="LoginMenu">
                <a>
                    LOGIN
                </a>
                <ul class="sub-menu">
                    <li style="font-size: 12px; ">
                        <a href="/auth/login" >Iniciar Sesión</a>
                    </li>
                    <li style="font-size: 12px; margin-left: 5px; ">
                        <a href="/auth/register" >Registrarse</a>
                    </li>
                </ul>
            </li>
        <?php endif; ?>
    </ul>
</div>