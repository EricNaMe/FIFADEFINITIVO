<?php $__env->startSection('content'); ?>
    <div id="menuLateral" style="background: url(/images/leftMenu.jpeg); background-size: cover;">
    <ul id="ListaMenuLateral">
      <li><a>CLUBES PRO</a>
      <li><a href="Inicio">HOME</a></li>
      <li><a>ADMINISTRADOR</a>
          <ul>
              <li><a href="/ProCrearLiga">CREAR LIGA</a></li>
              <li><a href="/ProCrearCopa">CREAR COPA</a></li>
              <li><a href="/ModificarLigaPro">MODIFICAR LIGA</a></li>
              <li><a href="/ModificarCopaPro">MODIFICAR COPA</a></li>
          </ul>
      </li>
        <li><a>LIGAS VIGENTES</a>
       <ul>
           <?php foreach($ligas as $liga): ?>
        <li><a href="EncontrarLiga/<?php echo e($liga->id); ?>"><?php echo e($liga->name); ?></a></li>

           <?php endforeach; ?>
        </ul>
        </li>
      <li><a>COPAS VIGENTES</a>
          <ul>
              <?php foreach($copas as $copa): ?>
                  <li><a href="EncontrarCopa/<?php echo e($copa->id); ?>"><?php echo e($copa->name); ?></a></li>

              <?php endforeach; ?>
          </ul>
      </li>
        <li><a>CLUBES</a>
    <ul>
        <li><a href="/clubes-pro/crear">CREAR CLUB</a></li>
        </ul>
        </li>
         <li><a href="Transferencias">TRANSFERENCIAS</a>
        </li>
         <li><a href="RankingCP">RANKING POR CLUBES</a>
        </li>
    </ul>
    </div>

    <?php echo $__env->make('partial.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div id="menuCentral" style="background:url(/images/middleMenu.jpeg); background-size: cover;" >
        <div>
            <ul id="MenuPerfil" style="position:relative; left:170px;width: 230px;">
                <li id="ListaPerfil"><a href="#">EQUIPOS SUSCRITOS</a></li>
            </ul>
        </div>

        <div id="TablaPrimeraClubesPro" style="position: absolute; top:20%; left:22%;">
            <table>
                <thead>
                    <tr>
                        <th>Número</th>
                        <th>Equipo</th>
                        <th>DT</th>
                    </tr>
                </thead>
                <?php $i=1; ?>
                <?php foreach($clubes as $club): ?>
                    <tr>
                        <td>
                            <div id="PosicionTabla">
                                <?php echo e($i); ?></div>
                        </td>
                        <td style=""><div id="LogoEquipo" style=" background:url(<?php echo e($club->getImageUrl()); ?>); background-size:cover;">
                            </div>
                            <a href="/clubes-pro/<?php echo e($club->id); ?>">
                                <?php echo e($club->name); ?>

                            </a>
                        </td>
                        <?php foreach($club->users as $user): ?>
                            <?php if($user->pivot->position==="DT"): ?>
                            <td>
                                <a href="/PerfilDetalles/<?php echo e($user->id); ?>">
                                    <?php echo e($user->user_name); ?>

                                </a>
                            </td>
                            <?php endif; ?>
                        <?php endforeach; ?>
                        <?php $i++; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>