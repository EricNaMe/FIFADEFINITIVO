<?php
/**
 * Created by PhpStorm.
 * User: sergio
 * Date: 25/03/16
 * Time: 01:58 PM
 */

namespace App\Exceptions;


class PermissionException extends \Exception
{

}